# llm_ana

Reversible byte-to-word codec that maps a directory tree into a stream of
high-frequency English words and back. Designed to make source code corpora
look like English text while remaining byte-perfect on round-trip.

## Pipeline

```
dir → CWM2 entry stream → zstd → 13-bit codec → 4-letter word stream
```

- **Container (CWM2)**: magic + flags + uncompressed-length + payload + CRC32.
- **Compression**: zstd level 19 (toggle with `--compress=none`).
- **Codec**: every 13-bit group → one of 8192 high-frequency 4-letter English
  words. No separators; the decoder strips all whitespace and splits every 4
  characters.

## Usage

```sh
# Encode a directory into a single text file.
llm_ana encode --in <dir> --out encoded.txt [--no-include-binary] [--verify]

# Decode it back into a directory.
llm_ana decode --in encoded.txt --out restored/
```

Flags:

| Flag | Default | Effect |
|------|---------|--------|
| `--include-binary` / `--no-include-binary` | include | Skip files with NUL bytes in the first 8 KiB. |
| `--compress=zstd` / `--compress=none` | zstd | Disable inner compression. |
| `--verify` | off | Re-decode immediately after encoding to confirm a clean round-trip. |

## Build

```sh
# Native build.
bazel build //src:llm_ana

# Cross-compile to Linux aarch64 / glibc 2.28 (zig-cc toolchain).
bazel build --platforms=//:linux_arm64 //src:llm_ana

# Package into a tarball.
bazel build --platforms=//:linux_arm64 //:release_linux_arm64
# → bazel-bin/release_linux_arm64.tar.gz (named llm_ana-linux-arm64-glibc2.28.tar.gz)
```

## Format constants

- Dictionary: 8192 norvig top-frequency 4-letter English words.
- 13 bits per word; 4 ASCII characters per word.
- Theoretical text expansion vs compressed byte stream: ≈ 2.46×.
